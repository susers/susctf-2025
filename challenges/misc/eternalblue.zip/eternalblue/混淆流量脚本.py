#!/usr/bin/env python3
"""
make_big_mixed_pcap.py

功能：
  - 生成大量背景流量（HTTP/DNS/TLS/SSH/SMB/ICMP/NTP/mDNS）
  - 将攻击 pcap 或 pcapng 切段后随机插入到背景流量时间轴，只微调时间戳
  - 攻击包内容完全不修改（IP、端口、payload 保留）
  - 流式写入，支持大文件生成
  - 使用 PcapNgWriter，兼容 Windows Scapy
"""

import argparse
import random
import time
from scapy.all import IP, TCP, UDP, ICMP, DNS, DNSQR, DNSRR, Raw, PcapReader
from scapy.utils import PcapNgWriter

# -------------------- 背景流量生成 --------------------


def random_seq():
    return random.randint(0, (1 << 32) - 1)


def gen_dns_query_pair(src, dst):
    qname = random.choice(
        ["seu.edu.cn", "seusus.com", "microsoft.com", "github.com", "login.local"]
    )
    sport = random.randint(20000, 55000)
    idv = random.randint(0, 0xFFFF)
    q = (
        IP(src=src, dst=dst)
        / UDP(sport=sport, dport=53)
        / DNS(id=idv, rd=1, qd=DNSQR(qname=qname))
    )
    a = (
        IP(src=dst, dst=src)
        / UDP(sport=53, dport=sport)
        / DNS(
            id=idv, qd=DNSQR(qname=qname), an=DNSRR(rrname=qname, rdata="93.184.216.34")
        )
    )
    return [q, a]


def gen_http_like_flow(src, dst):
    sport = random.randint(20000, 50000)
    syn = IP(src=src, dst=dst) / TCP(sport=sport, dport=80, flags="S", seq=random_seq())
    synack = IP(src=dst, dst=src) / TCP(
        sport=80, dport=sport, flags="SA", seq=random_seq(), ack=syn[TCP].seq + 1
    )
    ack = IP(src=src, dst=dst) / TCP(
        sport=sport, dport=80, flags="A", seq=syn[TCP].seq + 1, ack=synack[TCP].seq + 1
    )
    req = (
        IP(src=src, dst=dst)
        / TCP(
            sport=sport, dport=80, flags="PA", seq=ack[TCP].seq, ack=synack[TCP].seq + 1
        )
        / Raw(load=b"GET / HTTP/1.1\r\nHost: example.com\r\n\r\n")
    )
    resp = (
        IP(src=dst, dst=src)
        / TCP(
            sport=80, dport=sport, flags="PA", seq=synack[TCP].seq + 1, ack=ack[TCP].seq
        )
        / Raw(load=b"HTTP/1.1 200 OK\r\nContent-Length: 12\r\n\r\nHello world")
    )
    fin1 = IP(src=src, dst=dst) / TCP(
        sport=sport,
        dport=80,
        flags="FA",
        seq=req[TCP].seq + len(req[Raw].load),
        ack=resp[TCP].seq + len(resp[Raw].load),
    )
    fin2 = IP(src=dst, dst=src) / TCP(
        sport=80, dport=sport, flags="FA", seq=resp[TCP].seq + 1, ack=fin1[TCP].seq + 1
    )
    return [syn, synack, ack, req, resp, fin1, fin2]


def gen_tls_like_flow(src, dst):
    return gen_http_like_flow(src, dst)


def gen_ssh_handshake(src, dst):
    sport = random.randint(30000, 60000)
    syn = IP(src=src, dst=dst) / TCP(sport=sport, dport=22, flags="S", seq=random_seq())
    synack = IP(src=dst, dst=src) / TCP(
        sport=22, dport=sport, flags="SA", seq=random_seq(), ack=syn[TCP].seq + 1
    )
    ack = IP(src=src, dst=dst) / TCP(
        sport=sport, dport=22, flags="A", seq=syn[TCP].seq + 1, ack=synack[TCP].seq + 1
    )
    banner = (
        IP(src=dst, dst=src)
        / TCP(
            sport=22, dport=sport, flags="PA", seq=synack[TCP].seq + 1, ack=ack[TCP].seq
        )
        / Raw(load=b"SSH-2.0-OpenSSH_8.0\r\n")
    )
    return [syn, synack, ack, banner]


def gen_icmp(src, dst):
    return [IP(src=src, dst=dst) / ICMP()]


def gen_smb_like_flow(src, dst):
    sport = random.randint(30000, 60000)
    syn = IP(src=src, dst=dst) / TCP(
        sport=sport, dport=445, flags="S", seq=random_seq()
    )
    synack = IP(src=dst, dst=src) / TCP(
        sport=445, dport=sport, flags="SA", seq=random_seq(), ack=syn[TCP].seq + 1
    )
    ack = IP(src=src, dst=dst) / TCP(
        sport=sport, dport=445, flags="A", seq=syn[TCP].seq + 1, ack=synack[TCP].seq + 1
    )
    smb = (
        IP(src=src, dst=dst)
        / TCP(sport=sport, dport=445, flags="PA", seq=ack[TCP].seq, ack=synack[TCP].seq)
        / Raw(load=b"SMB2 NEGOTIATE")
    )
    return [syn, synack, ack, smb]


def gen_ntp(src, dst):
    sport = random.randint(20000, 60000)
    qpayload = bytes([0x1B]) + b"\x00" * 47
    rpayload = bytes([0x1C]) + b"\x00" * 47
    q = IP(src=src, dst=dst) / UDP(sport=sport, dport=123) / Raw(load=qpayload)
    r = IP(src=dst, dst=src) / UDP(sport=123, dport=sport) / Raw(load=rpayload)
    return [q, r]


def gen_mdns(src):
    dst = "224.0.0.251"
    sport = random.randint(20000, 40000)
    q = (
        IP(src=src, dst=dst)
        / UDP(sport=sport, dport=5353)
        / DNS(rd=1, qd=DNSQR(qname="device.local"))
    )
    return [q]


def choose_bg_target():
    if random.random() < 0.7:
        return random.choice(
            ["172.19.2.1", "151.101.1.69", "172.20.40.8", "172.20.40.9", "1.1.1.1"]
        )
    else:
        return f"10.0.{random.randint(0, 255)}.{random.randint(2, 250)}"


# -------------------- 主混合逻辑 --------------------


def stream_make_merged(
    attack_path, out_path, bg_flows, scale, scatter, seed=None, start_time=None
):
    if seed is not None:
        random.seed(seed)

    # Windows Scapy 兼容，不使用 append
    writer = PcapNgWriter(out_path)
    print(f"[+] 输出文件：{out_path}")

    # 读取攻击 pcap
    atk_reader = PcapReader(attack_path)
    atk_pkts = [p for p in atk_reader]
    atk_reader.close()
    if not atk_pkts:
        raise SystemExit("[!] 未读取到攻击包")
    print(f"[+] 攻击包总数: {len(atk_pkts)}")

    # 切分攻击包
    if scatter <= 1:
        atk_chunks = [atk_pkts]
    else:
        L = len(atk_pkts)
        chunk_size = max(1, L // scatter)
        atk_chunks = [atk_pkts[i : i + chunk_size] for i in range(0, L, chunk_size)]
        while len(atk_chunks) > scatter:
            atk_chunks[-2].extend(atk_chunks[-1])
            atk_chunks.pop()
        while len(atk_chunks) < scatter:
            atk_chunks.append([])
    print(f"[+] 攻击包分为 {len(atk_chunks)} 段")

    # 确定插入点
    insert_points = sorted(
        random.sample(range(max(1, bg_flows)), k=min(len(atk_chunks), bg_flows))
    )
    if not insert_points:
        insert_points = [bg_flows // 2 for _ in range(len(atk_chunks))]

    insert_points = [0] + insert_points

    print(f"[+] 攻击段将插入在背景 flow 索引: {insert_points[:10]} ...")

    base_time = start_time if start_time else time.time()
    inserted_chunks = 0

    for fidx in range(bg_flows):
        src = f"192.168.234.{random.randint(2, 250)}"
        dst = choose_bg_target()
        typ = random.choices(
            ["dns", "http", "tls", "ssh", "icmp", "smb", "mdns"],
            weights=[15, 25, 10, 5, 5, 25, 5],
            k=1,
        )[0]

        if typ == "dns":
            pkts = gen_dns_query_pair(src, dst)
        elif typ == "http":
            pkts = gen_http_like_flow(src, dst)
        elif typ == "tls":
            pkts = gen_tls_like_flow(src, dst)
        elif typ == "ssh":
            pkts = gen_ssh_handshake(src, dst)
        elif typ == "icmp":
            pkts = gen_icmp(src, dst)
        elif typ == "smb":
            pkts = gen_smb_like_flow(src, dst)
        elif typ == "ntp":
            pkts = gen_ntp(src, dst)
        elif typ == "mdns":
            pkts = gen_mdns(src)
        else:
            pkts = gen_http_like_flow(src, dst)

        # scale 放大流量
        for s in range(scale):
            tbase = (
                base_time
                + fidx * random.uniform(0.05, 2.0)
                + s * random.uniform(0.1, 10.0)
            )
            for i, p in enumerate(pkts):
                p.time = tbase + i * random.uniform(0.0005, 0.02)
                writer.write(p)

        # 插入攻击段（只修改时间戳）
        if inserted_chunks < len(atk_chunks) and fidx in insert_points:
            chunk = atk_chunks[inserted_chunks]
            insert_base = base_time + fidx * random.uniform(0.05, 2.0)
            for j, ap in enumerate(chunk):
                newp = ap.copy()
                newp.time = insert_base + j * random.uniform(0.0001, 0.005)
                writer.write(newp)
            print(
                f"[>] 插入攻击段 {inserted_chunks} (包 {len(chunk)}) 于 flow 索引 {fidx}"
            )
            inserted_chunks += 1

    # 末尾追加剩余攻击段
    for k in range(inserted_chunks, len(atk_chunks)):
        chunk = atk_chunks[k]
        base_end = base_time + bg_flows * 2.0 + (k + 1) * 0.5
        for j, ap in enumerate(chunk):
            newp = ap.copy()
            newp.time = base_end + j * random.uniform(0.0001, 0.005)
            writer.write(newp)
        print(f"[>] 末尾追加攻击段 {k}")

    writer.close()
    print("[+] 完成。")


# -------------------- CLI --------------------


def main():
    ap = argparse.ArgumentParser(
        description="生成背景流量并插入攻击 pcap，只修改时间戳"
    )
    ap.add_argument("--attack", required=True, help="攻击 pcap 文件")
    ap.add_argument("--out", default="merged_out.pcapng", help="输出文件，建议 pcapng")
    ap.add_argument("--bg-flows", type=int, default=20000, help="背景 flow 数量")
    ap.add_argument("--scale", type=int, default=3, help="背景流量放大倍数")
    ap.add_argument("--scatter", type=int, default=4, help="攻击包分段")
    ap.add_argument("--seed", type=int, default=None, help="随机种子")
    ap.add_argument("--start-time", type=float, default=None, help="起始时间戳")
    args = ap.parse_args()

    stream_make_merged(
        attack_path=args.attack,
        out_path=args.out,
        bg_flows=args.bg_flows,
        scale=args.scale,
        scatter=args.scatter,
        seed=args.seed,
        start_time=args.start_time,
    )


if __name__ == "__main__":
    main()
