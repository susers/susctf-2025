# FlagChat

用于 MoeCTF 2024 的 LLM 安全题。

## Deployment

1. Edit `.streamlit/secrets.toml`
2. Run `streamlit run app.py`

## License

WTFPL
