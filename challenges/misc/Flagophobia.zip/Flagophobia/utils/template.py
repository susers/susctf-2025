import streamlit as st
from jinja2 import Environment, FileSystemLoader
import json
import google.generativeai as genai

@st.cache_resource
def jinja_env(problem: str):
    return Environment(loader=FileSystemLoader(f"prompts/{problem}"))


def make_prompt_chain(problem: str, messages: list[dict], **kwargs):
    """Take a list of messages, prepend rendered system and user_prepend, and return a list of messages"""
    env = jinja_env(problem)
    system = env.get_template("system.md.jinja").render(**kwargs)
    user_prepend = env.get_template("user_prepend.md.jinja").render(**kwargs)
    print(messages)

    prepend = []
    if system:
        prepend.append(json.dumps({
   "contents": [
      {
         "role": "user",
         "parts": [
            {
               "text": system
            }
         ]
      },messages
   ]}))
    if user_prepend:
        prepend.append(json.dumps({
   "contents": [
      {
         "role": "user",
         "parts": [
            {
               "text": user_prepend
            }
         ]
      },messages
   ]}))
    return prepend
