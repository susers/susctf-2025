from datetime import datetime
import requests as rq
import streamlit as st
from sqlalchemy.dialects.sqlite import insert
from base64 import b64decode
from nacl.signing import VerifyKey
from schemas import users
import os

if USE_TEAM_HASH := "SUSCTF_FLAG_CONFIG" in os.environ:
    PUBLIC_KEY, CHAL_SALT, CHAL_ID = os.environ.get("SUSCTF_FLAG_CONFIG").split("@")
FLAG = os.environ.get("GZCTF_FLAG") or "susctf{test_flag}"

conn = st.connection("db", type="sql")

if "next_page" not in st.session_state:
    st.session_state.next_page = "app.py"


def verify_token(token: str) -> bool:
    verify_key = VerifyKey(b64decode(PUBLIC_KEY))
    data = f"GZCTF_TEAM_{token.split(':')[0]}".encode()
    try:
        verify_key.verify(data, b64decode(token.split(':')[1]))
        return True
    except:
        return False


#def verify_with_ret2shell(code: str) -> dict | None:
    #r2s_url = st.secrets.ret2shell_url
    #int_code = int(code, 16)
    #query = rq.get(f"{r2s_url}/api/account/query", params={"code": int_code})
    #if query.status_code == 200:
    #    return query.json()
    #return None

def create_or_update_user(user: dict):
    with conn.session as s:
        s.execute(
            insert(users)
            .values(
                id=user["id"],
                username=user["account"],
                last_login=datetime.now().timestamp(),
            )
            .on_conflict_do_update(
                index_elements=["id"],
                set_={
                    "last_login": datetime.now().timestamp(),
                },
            )
        )
        s.commit()


def login(user: dict):
    if user:
        st.session_state.id = user["id"]
        create_or_update_user(user)
        st.switch_page(st.session_state.next_page)
    else:
        st.error("登录失败，请检查 token 是否正确！")


#if st.secrets.debug:
#    login({"id": 0, "account": "test"})

st.title("Login with token")
code = st.text_input("请输入你的 token:")

if st.button("登录"):
    user = {"id":1, "account":"doctor"} #if verify_token(code) else None
    login(user)
