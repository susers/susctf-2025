import json

import streamlit as st
from openai import OpenAI
import requests

from utils.database import get_timeout_type, log_message
from utils.flag import get_flag
from utils.template import jinja_env, make_prompt_chain
import google.generativeai as genai
import os

#proxy_url = 'http://host.docker.internal:7897'
proxy_url = 'http://127.0.0.1:7897'

os.environ['HTTP_PROXY'] = proxy_url
os.environ['HTTPS_PROXY'] = proxy_url
os.environ['http_proxy'] = proxy_url
os.environ['https_proxy'] = proxy_url

# --- 新增函数，用于和你的代理进行通信 ---
def run_chat_via_proxy(history: list):
    """
    将完整的对话历史发送到 gemini-balance 代理并获取响应。
    """
    
    # 3. 你的代理期望以何种方式接收 API Key，通常是在请求头 (headers) 中。
    #    常见的请求头名称是 'x-api-key', 'api-key', 或 'Authorization': 'Bearer <key>'
    headers = {
        'Content-Type': 'application/json',
        'x-goog-api-key': st.secrets.genai.api_key
    }
    # --- 配置结束 ---

    # 将 Streamlit 的历史记录格式转换为 Gemini API 的格式
    # 关键：API 期望 assistant (助手) 的角色名称是 "model"，而不是 "assistant"。
    api_messages = []
    for msg in history:
        api_role = "user" if msg["role"] == "user" else "model"
        api_messages.append({
            "role": api_role,
            "parts": [{"text": msg["content"]}]
        })

    # 构建完整的请求数据体 (payload)，包括系统提示和生成配置
    payload = {
        "contents": api_messages,
        "systemInstruction": {
            "parts": [
                {
                    "text": jinja_env("guess_flag").get_template("system.md.jinja").render(flag=get_flag(st.session_state.id, "patient"))
                }
            ]
        },
        "generationConfig": {
            "maxOutputTokens": 200,
            "temperature": 0.1
        }
    }

    try:
        # 向你的本地代理发送 POST 请求
        response = requests.post(st.secrets.genai.base_url, headers=headers, data=json.dumps(payload))
        response.raise_for_status()  # 如果返回失败的状态码 (如 4xx 或 5xx)，则会抛出异常

        response_data = response.json()
        
        # 从响应中安全地提取内容和结束原因
        candidates = response_data.get("candidates", [])
        if not candidates:
            return "错误：从 API 收到了空的响应。", "ERROR"
            
        finish_reason = candidates[0].get("finishReason", "UNKNOWN")
        content = candidates[0].get("content", {}).get("parts", [{}])[0].get("text", "")
        
        return content, finish_reason

    except requests.exceptions.RequestException as e:
        st.error(f"连接代理时发生网络错误: {e}")
        return f"错误：无法连接到代理服务，地址：{st.secrets.genai.base_url}。", "ERROR"
    except (KeyError, IndexError) as e:
        st.error(f"解析 API 响应时出错: {e}")
        return "错误：API 响应的格式不符合预期。", "ERROR"


# --- 修改后的原始函数 ---

def reset_messages():
    st.session_state.messages = []
    st.session_state.filtered = False
    st.session_state.ended = False

def run_chat_complete():
    # 修改: 这个函数现在调用我们新的代理函数
    # 它将 session state 中的完整历史记录传递过去。
    resp_content, finish_reason = run_chat_via_proxy(st.session_state.messages)
    return resp_content, finish_reason

def render_completion(resp_content, finish_reason):
    if finish_reason != "SAFETY" and finish_reason != "ERROR":
        st.session_state.messages.append({"role": "assistant", "content": resp_content})
        with st.chat_message("assistant"):
            st.markdown(resp_content)
        if len(st.session_state.messages) >= 10:
            st.session_state.ended = True
            with st.chat_message("system", avatar="😷"):
                st.markdown("消息过多（至多 5 轮对话），请点击“重置消息”重新开始。")
    elif finish_reason == "SAFETY":
        st.session_state.ended = True
        st.session_state.filtered = True
        with st.chat_message("system", avatar="😷"):
            st.markdown("您的消息被过滤了，接下来一小时您将无法发送消息。")
    else: # 处理我们函数返回的错误
        with st.chat_message("assistant"):
            st.error(resp_content)


# --- 主脚本逻辑 (大部分未变) ---

if "id" not in st.session_state:
    st.session_state.next_page = "pages/guess_flag.py"
    st.switch_page("pages/login.py")

# 移除: 所有 genai.configure, GenerativeModel, 和 model.start_chat 的调用都已删除。
# 它们的逻辑被替换到了 run_chat_via_proxy() 函数内部。

if "messages" not in st.session_state or "filtered" not in st.session_state:
    reset_messages()

if st.button("重置消息"):
    reset_messages()

timeout_type = get_timeout_type(st.session_state.id)
is_in_timeout = timeout_type != "OK"

st.button(f"用户 ID: {st.session_state.id} 当前状态: {timeout_type} 点击以重载")

with st.chat_message("system", avatar="😷"):
    st.markdown(jinja_env("guess_flag").get_template("intro.md.jinja").render())

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

if prompt := st.chat_input(
    "每分钟最多发送 2 条消息，如果消息触发上游过滤，则一小时之内无法发送消息。",
    disabled=is_in_timeout or st.session_state.ended,
):
    if is_in_timeout or st.session_state.ended:
        with st.chat_message("system", avatar="😷"):
            st.markdown(f"当前无法发送消息（{timeout_type}）。点击上面的重载按钮来刷新状态。")

    elif len(prompt) <= 200:
        # 注意：原始代码在 prompt 前添加了 "Chat: "，我保留了这个行为。
        prompt_content = "Chat: " + prompt 
        st.session_state.messages.append({"role": "user", "content": prompt_content})
        with st.chat_message("user"):
            st.markdown(prompt_content)

        resp_content, finish_reason = run_chat_complete()
        render_completion(resp_content, finish_reason)
        log_message(
            user_id=st.session_state.id,
            type="guess_flag",
            msgs=json.dumps(st.session_state.messages, ensure_ascii=False),
            is_filtered=st.session_state.filtered,
        )

    else:
        with st.chat_message("system", avatar="😷"):
            st.markdown("消息过长，请重新发送。（最多 200 字）")