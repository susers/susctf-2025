const express = require("express");
const { MongoClient } = require("mongodb");
const { randomUUID } = require("crypto");

const flag = process.env.GZCTF_FLAG || "susctf{test}";

const app = express();
app.use(express.json());

const uri = "mongodb://localhost:27017";
const client = new MongoClient(uri);

async function run() {
  try {
    await client.connect();
    const db = client.db("nosqli");
    const users = db.collection("users");

    await users.insertOne({ username: "admin", password: randomUUID() });
    await users.insertOne({ username: flag, password: randomUUID() });

    app.post("/login", async (req, res) => {
      const username = req.body.username;
      const password = req.body.password;
      const query = {
        username: username,
        password: password,
      };

      try {
        const user = await users.findOne(query);
        if (user) {
          res.send(`Logged in as ${user.username}`);
        } else {
          res.status(401).send("Invalid credentials");
        }
      } catch (e) {
        console.log(e);
        res.status(500).send("Error during login");
      }
    });

    app.listen(3000, () => {
      console.log("Server running on http://localhost:3000");
    });
  } catch (err) {
    console.error(err);
  }
}

run();
