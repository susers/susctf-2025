./ferretdb --handler=sqlite --log-level=INFO &

node index.js
