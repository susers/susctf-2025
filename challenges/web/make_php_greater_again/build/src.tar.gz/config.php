<?php
CLASS Config{
    public function __construct(){
        include "vendor/autoload.php";
        include "vendor/vendor-prefixed/autoload.php";
    }





}
new Config();