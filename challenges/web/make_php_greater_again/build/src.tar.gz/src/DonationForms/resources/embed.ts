import {iframeResize} from 'iframe-resizer';

iframeResize({heightCalculationMethod: 'taggedElement'}, 'iframe[data-givewp-embed]');
