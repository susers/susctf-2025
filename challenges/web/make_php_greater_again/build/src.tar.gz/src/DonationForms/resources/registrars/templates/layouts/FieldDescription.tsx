export default function FieldDescription({description}) {
    return <p className="givewp-fields__description">{description}</p>;
}
