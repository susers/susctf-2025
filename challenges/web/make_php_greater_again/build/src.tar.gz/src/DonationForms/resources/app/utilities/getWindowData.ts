export default function getWindowData() {
    return window.givewpDonationFormExports;
}
